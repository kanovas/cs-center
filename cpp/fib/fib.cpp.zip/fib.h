#ifndef FIB_H
#define FIB_H

long long fib(int n);

#endif