package ru.compscicenter.java2014.calculator;

/**
 * Noli nocere!
 */
public interface BinaryExpression extends Expression{
	abstract double oper(double a, double b) throws ParserException;
}
