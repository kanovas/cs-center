package ru.compscicenter.java2014.calculator;

public interface Calculator {
    double calculate(String expression);
}
