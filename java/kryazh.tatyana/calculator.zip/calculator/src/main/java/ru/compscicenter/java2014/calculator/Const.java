package ru.compscicenter.java2014.calculator;

/**
 * Noli nocere!
 */
public class Const implements Expression {

	double c;

	public Const(double v) {
		c = v;
	}

	public double evaluate() {
		return c;
	}
}
