package ru.compscicenter.java2014.calculator;

/**
 * Noli nocere!
 */
public class ParserException extends Exception {
	public ParserException() {
		super();
	}
	public ParserException(String message) {
		super(message);
	}
}
