package ru.compscicenter.java2014.calculator;

/**
 * Noli nocere!
 */
public interface SingleExpression extends Expression {
	abstract double oper(double a);
}
