package ru.compscicenter.java2014.calculator;

/**
 * Noli nocere!
 */
public class Sin extends SingleOperation {
	public Sin(Expression a) {
		super(a);
	}

	public double oper(double a) {
		return Math.sin(a);
	}
}